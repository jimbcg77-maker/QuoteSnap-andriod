package com.incomeapp;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    LinearLayout layout;
    EditText customer, job, hours, rate, materials, tax;
    TextView result, saved;
    String current = "";
    SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("quotes", MODE_PRIVATE);
        ScrollView scroll = new ScrollView(this);
        layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 28, 28, 28);
        layout.setBackgroundColor(Color.WHITE);
        scroll.addView(layout);
        setContentView(scroll);
        TextView title = new TextView(this);
        title.setText("QuoteSnap\nSimple estimates, on your phone");
        title.setTextSize(25);
        title.setTextColor(Color.rgb(18, 54, 90));
        layout.addView(title);
        customer = field("Customer name", false);
        job = field("Job description", false);
        hours = field("Labor hours", true);
        rate = field("Hourly rate ($)", true);
        materials = field("Materials cost ($)", true);
        tax = field("Tax rate (%)", true);
        tax.setText("0");
        button("Calculate estimate", v -> calculate());
        button("Save estimate", v -> save());
        button("Share estimate", v -> share());
        result = new TextView(this);
        result.setTextSize(18);
        result.setTextColor(Color.BLACK);
        result.setPadding(0, 24, 0, 24);
        layout.addView(result);
        saved = new TextView(this);
        saved.setTextColor(Color.DKGRAY);
        saved.setTextSize(15);
        layout.addView(saved);
        refreshSaved();
    }
    EditText field(String hint, boolean number) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        if(number) e.setInputType(8194);
        layout.addView(e);
        return e;
    }
    void button(String text, View.OnClickListener action) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(action);
        layout.addView(b);
    }
    double num(EditText e) {
        try { return Math.max(0, Double.parseDouble(e.getText().toString().trim())); }
        catch(Exception ignored) { return 0; }
    }
    void calculate() {
        double labor = num(hours) * num(rate);
        double subtotal = labor + num(materials);
        double taxAmount = subtotal * num(tax) / 100.0;
        current = String.format(Locale.US,
            "QuoteSnap Estimate\nCustomer: %s\nJob: %s\nLabor: $%.2f\nMaterials: $%.2f\nTax: $%.2f\nTOTAL: $%.2f",
            customer.getText(), job.getText(), labor, num(materials), taxAmount, subtotal + taxAmount);
        result.setText(current);
    }
    void save() {
        calculate();
        String history = prefs.getString("history", "");
        String entry = current + "\n--------------------\n";
        prefs.edit().putString("history", (entry + history).substring(0, Math.min((entry + history).length(), 25000))).apply();
        Toast.makeText(this, "Saved on this phone", Toast.LENGTH_SHORT).show();
        refreshSaved();
    }
    void refreshSaved() {
        saved.setText("Saved estimates\n\n" + prefs.getString("history", "No estimates saved yet."));
    }
    void share() {
        calculate();
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, current);
        startActivity(Intent.createChooser(intent, "Share estimate"));
    }
}
