# QuoteSnap Android
A lightweight offline estimate maker for Android. Enter customer, job, labor hours/rate, materials and tax percentage; calculate totals; save estimates locally; share an estimate as text.

## Build
Push all files including `.github/workflows/build.yml` to a GitHub repository's `main` branch. Open Actions > Build Android APK > latest successful run > Artifacts > QuoteSnap-APK. Extract ZIP and install the APK on your Android device.

Uses Android Gradle Plugin 8.7.3, Gradle 8.9, Java 17, SDK 35. No Gradle wrapper required for the supplied GitHub workflow.

This project has not been compiled in this environment; GitHub Actions will perform the actual build.
